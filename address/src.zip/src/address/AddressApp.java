package address;

import address.gui.MainFrame;

public class AddressApp {

	public static void main(String[] args) {
		
		new MainFrame();
		
	}
}

